import { render, canvas } from './rendering.js';
import {eventHandling, renderTab} from './eventHandling.js';

renderTab('function');
render();
eventHandling();
