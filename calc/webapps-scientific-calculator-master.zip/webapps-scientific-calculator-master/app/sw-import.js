importScripts('lib/platinum-sw/service-worker.js');
